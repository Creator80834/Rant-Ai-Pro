
import React from 'react';
import { PRICING_PLANS, Icons } from './constants';
import { PlanType } from './types';

interface PricingSectionProps {
  currentPlan?: PlanType;
  onUpgrade: (plan: PlanType) => void;
}

const PricingSection: React.FC<PricingSectionProps> = ({ currentPlan, onUpgrade }) => {
  return (
    <div className="py-24 border-t border-white/5">
      <div className="text-center mb-16">
        <h2 className="text-6xl font-bebas tracking-wider text-white mb-4 italic">UPGRADE <span className="text-roblox-red">STATUS</span></h2>
        <p className="text-gray-500 max-w-lg mx-auto font-medium">Unlock vintage slang, nuclear intensity, and the elite creator engine.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {PRICING_PLANS.map((plan) => {
          const isCurrent = currentPlan === plan.type;
          return (
            <div key={plan.type} className={`bg-[#16181d] border-2 rounded-3xl p-10 flex flex-col transition-all ${plan.popular ? 'border-roblox-red scale-105 shadow-2xl z-10' : 'border-white/5 opacity-80'}`}>
              <div className="mb-8">
                <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] mb-2">{plan.name}</h3>
                <div className="flex items-baseline space-x-1">
                  <span className="text-4xl font-bebas text-white">{plan.price}</span>
                  {plan.period && <span className="text-gray-500 text-xs font-black uppercase tracking-widest">{plan.period}</span>}
                </div>
              </div>

              <ul className="space-y-4 mb-10 flex-grow">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-center space-x-3 text-xs text-gray-400 font-bold">
                    <span className="text-green-500"><Icons.Check /></span>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <button 
                onClick={() => !isCurrent && onUpgrade(plan.type)}
                className={`w-full py-4 rounded-xl font-black uppercase tracking-widest text-[10px] transition-all ${isCurrent ? 'bg-white/5 text-gray-600 cursor-default' : 'bg-roblox-red text-white hover:bg-red-600 shadow-xl'}`}
              >
                {isCurrent ? 'Active Plan' : 'Select Package'}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default PricingSection;
