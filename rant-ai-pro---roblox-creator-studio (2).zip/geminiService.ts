
import { GoogleGenAI, Modality } from "@google/genai";
import { RantConfig, Persona, SlangStyle } from "./types";

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const personaToVoice: Record<string, string> = {
  [Persona.VETERAN]: 'Charon',
  [Persona.NOOB]: 'Puck',
  [Persona.DEVELOPER]: 'Kore',
  [Persona.RICH_KID]: 'Fenrir',
  [Persona.GAMER_GIRL]: 'Kore',
  [Persona.TRADER]: 'Zephyr'
};

export const generateAudioRant = async (text: string, persona: Persona): Promise<AudioBuffer> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const voiceName = personaToVoice[persona] || 'Kore';
  const cleanText = text.replace(/\[VISUAL:.*?\]/g, '').replace(/\[NARRATOR\]:/g, '').replace(/CHAPTER \d+: /g, '');

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `Read this script with absolute chaos and viral energy: ${cleanText}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName },
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) throw new Error("Audio synthesis failed.");

  const AudioContextClass = (window as any).AudioContext || (window as any).webkitAudioContext;
  const audioContext = new AudioContextClass({ sampleRate: 24000 });
  return await decodeAudioData(decode(base64Audio), audioContext, 24000, 1);
};

export const generateRobloxRant = async (config: RantConfig): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const slangMap = {
    [SlangStyle.CLASSIC]: "2008 era Roblox: 'tix', 'pwned', 'noob', 'Oof sound', 'Builders Club'.",
    [SlangStyle.MODERN]: "2024 Roblox: 'skill issue', 'L', 'ratio', 'slender', 'mic up'.",
    [SlangStyle.GEN_ALPHA]: "Gen Alpha brainrot: 'skibidi', 'rizz', 'fanum tax', 'gyatt', 'sigma'.",
    [SlangStyle.TECHNICAL]: "Developer terms: 'DataStore outages', 'API rate limits', 'UGC verification fees'."
  };

  const systemInstruction = `You are a high-energy Roblox Drama YouTuber. Write a viral rant about "${config.topic}". 
  Persona: ${config.persona}. 
  Intensity Level: ${config.intensity}. 
  Required Slang: ${config.slangStyles.map(s => slangMap[s]).join(', ')}. 
  Format with CHAPTER markers and [VISUAL: cue] markers for video editors.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: [{ role: 'user', parts: [{ text: `Create an absolute masterpiece of a rant targeting ${config.target} about ${config.topic}.` }] }],
    config: { systemInstruction, temperature: 1.0 }
  });

  return response.text || "Critical Error: Engine failed to spark.";
};
