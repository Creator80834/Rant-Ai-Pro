
import React, { useState } from 'react';
import { Intensity, Persona, RantConfig, RantLength, SlangStyle, PlanType } from './types';

interface RantGeneratorProps {
  onGenerate: (config: RantConfig) => void;
  isGenerating: boolean;
  userPlan?: PlanType;
  onShowPricing: () => void;
}

const RantGenerator: React.FC<RantGeneratorProps> = ({ onGenerate, isGenerating, userPlan = PlanType.FREE, onShowPricing }) => {
  const [topic, setTopic] = useState('');
  const [target, setTarget] = useState('Everyone');
  const [intensity, setIntensity] = useState<Intensity>(Intensity.ANGRY);
  const [persona, setPersona] = useState<Persona>(Persona.VETERAN);
  const [length, setLength] = useState<RantLength>(RantLength.MEDIUM);
  const [selectedSlang, setSelectedSlang] = useState<SlangStyle>(SlangStyle.MODERN);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate({ topic, target, intensity, persona, length, slangStyles: [selectedSlang], grievances: [] });
  };

  return (
    <div className="bg-[#16181d] p-8 rounded-2xl border border-white/5 shadow-2xl space-y-8">
      <div className="flex items-center justify-between border-b border-white/5 pb-6">
        <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-widest italic">Production Studio v1.0</h3>
        <span className="flex space-x-1">
          <span className="w-1.5 h-1.5 bg-roblox-red rounded-full animate-pulse"></span>
          <span className="w-1.5 h-1.5 bg-gray-700 rounded-full"></span>
        </span>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-[10px] font-black text-gray-500 uppercase mb-2 tracking-widest">Target Topic</label>
          <input 
            type="text" 
            value={topic} 
            onChange={(e) => setTopic(e.target.value)} 
            placeholder="e.g. Blox Fruits Update Delay..." 
            className="w-full bg-black border border-white/10 rounded-xl px-5 py-3 text-white focus:ring-2 focus:ring-roblox-red outline-none placeholder:text-gray-700 transition-all" 
            required 
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-[10px] font-black text-gray-500 uppercase mb-2 tracking-widest">Intensity</label>
            <select value={intensity} onChange={(e) => setIntensity(e.target.value as Intensity)} className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-xs text-white outline-none">
              {Object.values(Intensity).map(i => <option key={i} value={i}>{i}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-[10px] font-black text-gray-500 uppercase mb-2 tracking-widest">Persona</label>
            <select value={persona} onChange={(e) => setPersona(e.target.value as Persona)} className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-xs text-white outline-none">
              {Object.values(Persona).map(p => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-[10px] font-black text-gray-500 uppercase mb-2 tracking-widest">Slang Style</label>
          <div className="grid grid-cols-2 gap-2">
            {Object.values(SlangStyle).map(style => (
              <button
                key={style}
                type="button"
                onClick={() => setSelectedSlang(style)}
                className={`py-2 px-3 rounded-lg text-[9px] font-black uppercase tracking-widest border transition-all ${selectedSlang === style ? 'bg-roblox-red border-roblox-red text-white' : 'bg-black border-white/10 text-gray-500 hover:border-gray-700'}`}
              >
                {style.split('(')[0]}
              </button>
            ))}
          </div>
        </div>

        <button 
          type="submit" 
          disabled={isGenerating} 
          className="w-full py-5 bg-roblox-red hover:bg-red-600 text-white rounded-2xl font-black tracking-[0.2em] text-sm transition-all active:scale-[0.98] disabled:opacity-50 shadow-[0_10px_30px_rgba(246,65,65,0.3)]"
        >
          {isGenerating ? "INITIALIZING..." : "EXECUTE RANT"}
        </button>
      </form>
    </div>
  );
};

export default RantGenerator;
