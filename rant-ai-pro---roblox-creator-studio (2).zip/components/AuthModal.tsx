
import React, { useState } from 'react';
import { User, PlanType } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: User) => void;
}

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedPlan, setSelectedPlan] = useState<PlanType>(PlanType.FREE);
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    setTimeout(() => {
      const mockUser: User = {
        username: username || (email.split('@')[0]),
        email: email,
        avatarSeed: (username || email).toLowerCase(),
        plan: selectedPlan,
        joinDate: Date.now(),
      };
      onSuccess(mockUser);
      setIsLoading(false);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={onClose} />
      
      <div className="relative w-full max-w-md bg-roblox-dark border border-roblox rounded-2xl shadow-2xl overflow-hidden animate-fade-in">
        <div className="p-8">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-roblox-red rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-[0_0_30px_rgba(246,65,65,0.4)] rotate-3">
              <span className="text-4xl font-black text-white italic">R</span>
            </div>
            <h2 className="text-3xl font-bebas tracking-wider text-white">
              {isLogin ? 'WELCOME BACK' : 'JOIN THE RAGE'}
            </h2>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <>
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Username</label>
                  <input type="text" required value={username} onChange={(e) => setUsername(e.target.value)} className="w-full bg-[#0b0d11] border border-roblox rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-roblox-red" placeholder="BaconHair99" />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Select Starting Plan</label>
                  <select value={selectedPlan} onChange={(e) => setSelectedPlan(e.target.value as PlanType)} className="w-full bg-[#0b0d11] border border-roblox rounded-lg px-4 py-3 text-white text-xs uppercase font-bold tracking-widest">
                    <option value={PlanType.FREE}>FREE (BACON)</option>
                    <option value={PlanType.PRO}>PRO (VETERAN)</option>
                    <option value={PlanType.PREMIUM}>PREMIUM (ELITE)</option>
                  </select>
                </div>
              </>
            )}
            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Email Address</label>
              <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="w-full bg-[#0b0d11] border border-roblox rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-roblox-red" placeholder="bobux@roblox.com" />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Password</label>
              <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} className="w-full bg-[#0b0d11] border border-roblox rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-roblox-red" placeholder="••••••••" />
            </div>

            <button type="submit" disabled={isLoading} className="w-full py-4 bg-roblox-red text-white font-bold rounded-xl shadow-lg hover:bg-red-600 transition-all">
              {isLoading ? (
                <div className="flex items-center justify-center space-x-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span className="animate-pulse uppercase tracking-widest">Verifying...</span>
                </div>
              ) : (
                <span className="font-bebas text-xl tracking-widest">{isLogin ? 'AUTHENTICATE' : 'INITIALIZE ACCOUNT'}</span>
              )}
            </button>
          </form>

          <div className="mt-6 text-center">
            <button onClick={() => setIsLogin(!isLogin)} className="text-xs text-gray-500 hover:text-roblox-red transition-colors">
              {isLogin ? "Don't have an account? Sign up" : "Already have an account? Log in"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;
