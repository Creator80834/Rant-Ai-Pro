
import React, { useState } from 'react';
import { GeneratedRant } from '../types';
import { Icons } from '../constants';
import { generateAudioRant } from '../services/geminiService';

interface RantOutputProps {
  rant: GeneratedRant | null;
  onPublished?: () => void;
}

const RantOutput: React.FC<RantOutputProps> = ({ rant, onPublished }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isSynthesizing, setIsSynthesizing] = useState(false);

  const handlePlay = async () => {
    if (!rant || isSynthesizing) return;
    setIsSynthesizing(true);
    try {
      const buffer = await generateAudioRant(rant.text, rant.config.persona);
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.connect(ctx.destination);
      source.onended = () => setIsPlaying(false);
      source.start(0);
      setIsPlaying(true);
    } catch (e) {
      alert("Audio Error.");
    } finally {
      setIsSynthesizing(false);
    }
  };

  if (!rant) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[500px] border-2 border-dashed border-roblox rounded-3xl p-12 text-center">
        <div className="w-20 h-20 bg-roblox-red/10 rounded-full flex items-center justify-center mb-6">
          <Icons.Flame />
        </div>
        <h3 className="text-xl font-bebas text-white uppercase tracking-widest">Studio Standby</h3>
        <p className="text-gray-500 text-sm italic">Ready to record. Generate a script to begin.</p>
      </div>
    );
  }

  return (
    <div className="bg-roblox-dark rounded-3xl border border-roblox overflow-hidden shadow-2xl flex flex-col h-full max-h-[800px]">
      <div className="bg-[#252a33] p-5 flex justify-between items-center border-b border-roblox">
        <span className="text-[10px] font-black text-white uppercase tracking-widest">Script Editor: {rant.config.topic}</span>
        <div className="flex space-x-2">
           <div className="w-2 h-2 bg-red-500 rounded-full"></div>
           <div className="w-2 h-2 bg-green-500 rounded-full"></div>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-12 bg-black text-gray-200 font-mono text-sm space-y-6 custom-scrollbar">
        {rant.text.split('\n').map((line, i) => (
          <p key={i} className={line.startsWith('CHAPTER') ? 'text-roblox-red font-black text-lg' : ''}>{line}</p>
        ))}
      </div>

      <div className="bg-[#0b0d11] p-6 border-t border-roblox flex gap-4">
        <button 
          onClick={handlePlay} 
          disabled={isSynthesizing}
          className="flex-1 py-3 bg-white/5 border border-roblox rounded-xl text-[10px] font-black uppercase text-white hover:bg-white/10"
        >
          {isSynthesizing ? "Synthesizing..." : isPlaying ? "Playing..." : "Sync Narration"}
        </button>
        <button 
          onClick={onPublished}
          className="flex-1 py-3 bg-roblox-red rounded-xl text-[10px] font-black uppercase text-white hover:bg-red-600"
        >
          Publish to Feed
        </button>
      </div>
    </div>
  );
};

export default RantOutput;
