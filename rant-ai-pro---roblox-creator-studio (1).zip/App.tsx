
import React, { useState, useEffect, useRef } from 'react';
import RantGenerator from './RantGenerator';
import RantOutput from './RantOutput';
import RantHistory from './RantHistory';
import AuthModal from './AuthModal';
import PricingSection from './PricingSection';
import { RantConfig, GeneratedRant, User, PlanType } from './types';
import { generateRobloxRant } from './geminiService';
import { Icons } from './constants';

const STORAGE_KEY = 'roblorant_history_v1';
const USER_KEY = 'roblorant_user_v1';

const App: React.FC = () => {
  const [currentRant, setCurrentRant] = useState<GeneratedRant | null>(null);
  const [history, setHistory] = useState<GeneratedRant[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [onlineCreators, setOnlineCreators] = useState(1240);
  const [notifications, setNotifications] = useState<{id: number, text: string}[]>([]);
  
  const pricingRef = useRef<HTMLDivElement>(null);
  const outputRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const savedHistory = localStorage.getItem(STORAGE_KEY);
    if (savedHistory) try { setHistory(JSON.parse(savedHistory)); } catch (e) {}
    const savedUser = localStorage.getItem(USER_KEY);
    if (savedUser) try { setCurrentUser(JSON.parse(savedUser)); } catch (e) {}

    const interval = setInterval(() => {
      setOnlineCreators(prev => prev + (Math.random() > 0.5 ? 1 : -1));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => localStorage.setItem(STORAGE_KEY, JSON.stringify(history)), [history]);

  const addNotification = (text: string) => {
    const id = Date.now();
    setNotifications(prev => [...prev, {id, text}]);
    setTimeout(() => setNotifications(prev => prev.filter(n => n.id !== id)), 4000);
  };

  const handleGenerate = async (config: RantConfig) => {
    setIsGenerating(true);
    if (window.innerWidth < 1024) outputRef.current?.scrollIntoView({ behavior: 'smooth' });
    
    try {
      const text = await generateRobloxRant(config);
      const newRant: GeneratedRant = { text, timestamp: Date.now(), config };
      setCurrentRant(newRant);
      setHistory(prev => [newRant, ...prev].slice(0, 20));
      addNotification("Script Generated Successfully.");
    } catch (err) {
      addNotification("Generation Failed. Verify API Key.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col selection:bg-roblox-red selection:text-white bg-[#0b0d11]">
      <div className="fixed top-24 right-8 z-[120] flex flex-col space-y-3 pointer-events-none">
        {notifications.map(n => (
          <div key={n.id} className="bg-roblox-red text-white px-6 py-3 rounded-2xl shadow-2xl font-black text-[10px] uppercase tracking-widest animate-fade-in flex items-center space-x-3 border border-white/10">
            <Icons.Check />
            <span>{n.text}</span>
          </div>
        ))}
      </div>

      <header className="py-5 px-8 border-b border-white/10 sticky top-0 z-50 bg-[#0b0d11]/90 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4 cursor-pointer" onClick={() => window.scrollTo({top:0, behavior:'smooth'})}>
            <div className="w-10 h-10 bg-roblox-red rounded-lg flex items-center justify-center shadow-lg">
              <span className="text-2xl font-black text-white italic">R</span>
            </div>
            <h1 className="text-xl font-bebas tracking-wider text-white">RANT<span className="text-roblox-red"> STUDIO</span></h1>
          </div>
          
          <div className="flex items-center space-x-6">
            <button onClick={() => setIsHistoryOpen(true)} className="text-[10px] font-black text-gray-400 hover:text-white uppercase tracking-widest">PROJECTS</button>
            {currentUser ? (
              <button onClick={() => setCurrentUser(null)} className="flex items-center space-x-3 bg-white/5 px-4 py-2 rounded-xl border border-white/10">
                <img src={`https://picsum.photos/seed/${currentUser.avatarSeed}/32/32`} className="w-6 h-6 rounded-md" alt="" />
                <span className="text-[10px] font-black text-white uppercase">{currentUser.username}</span>
              </button>
            ) : (
              <button onClick={() => setIsAuthOpen(true)} className="bg-white text-black px-5 py-2 rounded-lg text-[10px] font-black tracking-widest uppercase hover:bg-roblox-red hover:text-white transition-all">LOG IN</button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto pt-20 pb-12 px-8 w-full flex-grow">
        <div className="text-center mb-16">
          <h2 className="text-7xl md:text-9xl font-bebas tracking-tighter text-white mb-2 leading-none italic uppercase">VIRAL <span className="text-roblox-red">DRAMA.</span></h2>
          <p className="text-gray-500 text-lg max-w-xl mx-auto font-medium">The ultimate script engine for Roblox creators.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-5 lg:sticky lg:top-28">
            <RantGenerator 
              onGenerate={handleGenerate} 
              isGenerating={isGenerating} 
              userPlan={currentUser?.plan}
              onShowPricing={() => pricingRef.current?.scrollIntoView({behavior:'smooth'})}
            />
          </div>
          <div ref={outputRef} className="lg:col-span-7">
            <RantOutput 
              rant={currentRant} 
              onPublished={() => addNotification("Published to Feed!")}
            />
          </div>
        </div>

        <div ref={pricingRef} className="mt-24">
          <PricingSection currentPlan={currentUser?.plan} onUpgrade={(p) => {
            if(currentUser) setCurrentUser({...currentUser, plan: p});
            else setIsAuthOpen(true);
          }} />
        </div>
      </main>

      <RantHistory 
        history={history} 
        isOpen={isHistoryOpen} 
        onClose={() => setIsHistoryOpen(false)} 
        onSelect={setCurrentRant} 
        onClear={() => setHistory([])} 
        onDelete={(ts) => setHistory(prev => prev.filter(r => r.timestamp !== ts))} 
      />
      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} onSuccess={setCurrentUser} />
    </div>
  );
};

export default App;
