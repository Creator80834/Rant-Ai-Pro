
import React, { useState, useMemo } from 'react';
import { GeneratedRant } from './types';
import { Icons } from './constants';

interface RantHistoryProps {
  history: GeneratedRant[];
  isOpen: boolean;
  onClose: () => void;
  onSelect: (rant: GeneratedRant) => void;
  onClear: () => void;
  onDelete: (timestamp: number) => void;
}

const RantHistory: React.FC<RantHistoryProps> = ({ 
  history, 
  isOpen, 
  onClose, 
  onSelect, 
  onClear,
  onDelete
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredHistory = useMemo(() => {
    if (!searchQuery.trim()) return history;
    const query = searchQuery.trim().toLowerCase();
    
    return history.filter(rant => {
      const content = `${rant.config.topic} ${rant.text}`.toLowerCase();
      // Simple search for now to ensure stability
      return content.includes(query);
    });
  }, [history, searchQuery]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={onClose} />
      
      <div className="relative w-full max-w-2xl bg-[#16181d] border border-white/10 rounded-3xl shadow-2xl flex flex-col max-h-[80vh] overflow-hidden animate-fade-in">
        <div className="p-6 border-b border-white/5 bg-black/20">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bebas tracking-wider text-white">PROJECT LOGS</h2>
            <div className="flex items-center space-x-4">
              {history.length > 0 && (
                <button onClick={onClear} className="text-[10px] font-black text-gray-500 hover:text-roblox-red uppercase tracking-widest">Wipe All</button>
              )}
              <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
          </div>

          <div className="relative">
            <input
              type="text"
              placeholder="Search scripts..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-black border border-white/10 rounded-xl pl-4 pr-10 py-3 text-sm text-white focus:ring-1 focus:ring-roblox-red outline-none"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 custom-scrollbar space-y-4">
          {filteredHistory.length === 0 ? (
            <div className="text-center py-20 opacity-30">
              <p className="text-white font-black uppercase tracking-widest">No matching logs found</p>
            </div>
          ) : (
            filteredHistory.map((rant) => (
              <div 
                key={rant.timestamp}
                className="group relative bg-black/40 border border-white/5 rounded-2xl p-5 hover:border-roblox-red transition-all cursor-pointer"
                onClick={() => { onSelect(rant); onClose(); }}
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-white font-bold text-sm uppercase tracking-tight">{rant.config.topic}</h3>
                  <span className="text-[9px] text-gray-600 font-black uppercase">
                    {new Date(rant.timestamp).toLocaleDateString()}
                  </span>
                </div>
                <p className="text-gray-500 text-[11px] line-clamp-1 italic mb-3">"{rant.text.substring(0, 100)}..."</p>
                <div className="flex gap-2">
                  <span className="text-[8px] bg-white/5 text-gray-400 px-2 py-1 rounded-md uppercase font-black">{rant.config.intensity}</span>
                  <span className="text-[8px] bg-white/5 text-gray-400 px-2 py-1 rounded-md uppercase font-black">{rant.config.persona}</span>
                </div>
                <button 
                  onClick={(e) => { e.stopPropagation(); onDelete(rant.timestamp); }}
                  className="absolute top-5 right-5 text-gray-700 hover:text-roblox-red opacity-0 group-hover:opacity-100 transition-all"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default RantHistory;
