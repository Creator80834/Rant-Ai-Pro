
import React, { useState } from 'react';
import { User, PlanType } from './types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: User) => void;
}

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      onSuccess({
        username: username || email.split('@')[0],
        email: email,
        avatarSeed: (username || email).toLowerCase(),
        plan: PlanType.FREE,
        joinDate: Date.now(),
      });
      setIsLoading(false);
      onClose();
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/90 backdrop-blur-md" onClick={onClose} />
      <div className="relative w-full max-w-md bg-[#16181d] border border-white/10 rounded-3xl shadow-2xl overflow-hidden animate-fade-in p-10">
        <div className="text-center mb-8">
          <div className="w-12 h-12 bg-roblox-red rounded-xl flex items-center justify-center mx-auto mb-4 rotate-3 shadow-xl">
            <span className="text-2xl font-black text-white italic">R</span>
          </div>
          <h2 className="text-3xl font-bebas tracking-wider text-white">{isLogin ? 'WELCOME BACK' : 'JOIN THE RAGE'}</h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <div>
              <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1.5">Username</label>
              <input type="text" required value={username} onChange={(e) => setUsername(e.target.value)} className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-roblox-red outline-none" placeholder="BaconHair99" />
            </div>
          )}
          <div>
            <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1.5">Email</label>
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-roblox-red outline-none" placeholder="creator@studio.com" />
          </div>
          <div>
            <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1.5">Password</label>
            <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-roblox-red outline-none" placeholder="••••••••" />
          </div>

          <button type="submit" disabled={isLoading} className="w-full py-4 bg-roblox-red text-white font-black rounded-xl uppercase tracking-widest text-xs hover:bg-red-600 transition-all mt-4">
            {isLoading ? "Verifying..." : isLogin ? "Authenticate" : "Create Account"}
          </button>
        </form>

        <button onClick={() => setIsLogin(!isLogin)} className="w-full text-center mt-6 text-[10px] text-gray-500 font-black uppercase tracking-widest hover:text-white transition-colors">
          {isLogin ? "Need an account? Sign up" : "Already registered? Log in"}
        </button>
      </div>
    </div>
  );
};

export default AuthModal;
