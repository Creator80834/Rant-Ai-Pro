
import { GoogleGenAI, Modality } from "@google/genai";
import { RantConfig, RantLength, SlangStyle, Persona } from "../types";

// Helper to decode base64 to Uint8Array
function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

// Helper to decode PCM data to AudioBuffer
async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const personaToVoice: Record<string, string> = {
  [Persona.VETERAN]: 'Charon',
  [Persona.NOOB]: 'Puck',
  [Persona.DEVELOPER]: 'Kore',
  [Persona.RICH_KID]: 'Fenrir',
  [Persona.GAMER_GIRL]: 'Kore',
  [Persona.TRADER]: 'Zephyr'
};

export const generateAudioRant = async (text: string, persona: Persona): Promise<AudioBuffer> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const voiceName = personaToVoice[persona] || 'Kore';
  
  // Strip visual and chapter tags for TTS
  const cleanText = text.replace(/\[VISUAL:.*?\]/g, '').replace(/\[NARRATOR\]:/g, '').replace(/CHAPTER \d+: /g, '');

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `Read this script with intense emotion and viral creator energy: ${cleanText}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName },
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) throw new Error("Audio synthesis engine failed to return data.");

  const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
  const audioBytes = decode(base64Audio);
  return await decodeAudioData(audioBytes, audioContext, 24000, 1);
};

export const generateTopicImage = async (topic: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `A cinematic 3D Roblox thumbnail render for: "${topic}". Intense dramatic lighting, blocky iconic characters, high resolution 4k, trending on Roblox.`;
  
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: [{ parts: [{ text: prompt }] }]
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
  }
  throw new Error("No image data returned from generator.");
};

export const generateRobloxRant = async (config: RantConfig): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const slangMap = {
    [SlangStyle.CLASSIC]: "Old school Roblox slang (2008-2012): 'tix', 'pwned', 'noob', 'builders club', 'oof'.",
    [SlangStyle.MODERN]: "Current Roblox slang: 'skill issue', 'L', 'ratio', 'mid', 'mic up', 'slender'.",
    [SlangStyle.GEN_ALPHA]: "Brainrot slang: 'skibidi', 'rizz', 'fanum tax', 'sigma', 'gyatt', 'ohio'.",
    [SlangStyle.TECHNICAL]: "Developer terms: 'DataStore lag', 'API error', 'Lua scripting', 'UGC fees'."
  };

  const systemInstruction = `You are a viral Roblox Drama YouTuber. 
    Write a high-intensity script about "${config.topic}".
    Persona: ${config.persona}.
    Intensity Level: ${config.intensity}.
    Slang Styles to use: ${config.slangStyles.map(s => slangMap[s]).join(', ')}.
    Include CHAPTER headers and [VISUAL: cue] instructions.
    Apply "#######" to censor extreme words like the Roblox chat filter.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: [{ role: 'user', parts: [{ text: `Create a script targeting ${config.target} about ${config.topic}. Specific issues: ${config.grievances.join(', ')}.` }] }],
    config: { systemInstruction, temperature: 1.0 }
  });

  return response.text || "Failed to generate script.";
};
