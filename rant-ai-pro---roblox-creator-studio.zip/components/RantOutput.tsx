
import React, { useState, useEffect, useRef } from 'react';
import { GeneratedRant } from '../types';
import { Icons } from '../constants';
import { generateAudioRant } from '../services/geminiService';

interface RantOutputProps {
  rant: GeneratedRant | null;
  onUpdate?: (updatedText: string) => void;
  onFeedback?: (feedback: 'up' | 'down') => void;
  onPublished?: () => void;
}

const RantOutput: React.FC<RantOutputProps> = ({ rant, onUpdate, onFeedback, onPublished }) => {
  const [viewMode, setViewMode] = useState<'script' | 'teleprompter'>('script');
  const [copied, setCopied] = useState(false);
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [isPublishing, setIsPublishing] = useState(false);
  const [isPublished, setIsPublished] = useState(false);
  
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const scrollIntervalRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (audioSourceRef.current) audioSourceRef.current.stop();
      if (scrollIntervalRef.current) window.clearInterval(scrollIntervalRef.current);
    };
  }, []);

  // Reset published state when rant changes
  useEffect(() => {
    setIsPublished(false);
  }, [rant?.timestamp]);

  // Teleprompter Auto-Scroll Logic
  useEffect(() => {
    if (isPlaying && viewMode === 'teleprompter' && scrollContainerRef.current && duration > 0) {
      const container = scrollContainerRef.current;
      const scrollHeight = container.scrollHeight - container.clientHeight;
      const startTime = Date.now();
      
      scrollIntervalRef.current = window.setInterval(() => {
        const elapsed = (Date.now() - startTime) / 1000;
        const progress = Math.min(elapsed / duration, 1);
        container.scrollTop = scrollHeight * progress;
        
        if (progress >= 1) {
          if (scrollIntervalRef.current) window.clearInterval(scrollIntervalRef.current);
        }
      }, 50);
    } else {
      if (scrollIntervalRef.current) window.clearInterval(scrollIntervalRef.current);
    }
  }, [isPlaying, viewMode, duration]);

  const handleCopy = () => {
    if (!rant) return;
    navigator.clipboard.writeText(rant.text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePublish = () => {
    if (!rant || isPublishing) return;
    setIsPublishing(true);
    // Simulate broadcasting to community
    setTimeout(() => {
      setIsPublishing(false);
      setIsPublished(true);
      if (onPublished) onPublished();
      setTimeout(() => setIsPublished(false), 3000);
    }, 2500);
  };

  const handleDownload = () => {
    if (!rant) return;
    const blob = new Blob([rant.text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `roblox-rant-${rant.config.topic.replace(/\s+/g, '-').toLowerCase()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleSynthesize = async () => {
    if (!rant || isSynthesizing) return;
    
    if (isPlaying) {
      audioSourceRef.current?.stop();
      setIsPlaying(false);
      return;
    }

    setIsSynthesizing(true);
    try {
      const buffer = await generateAudioRant(rant.text, rant.config.persona);
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.connect(ctx.destination);
      setDuration(buffer.duration);
      
      source.onended = () => {
        setIsPlaying(false);
        setDuration(0);
      };
      
      audioSourceRef.current = source;
      source.start(0);
      setIsPlaying(true);
    } catch (e) {
      console.error("Audio failed", e);
    } finally {
      setIsSynthesizing(false);
    }
  };

  const renderContent = () => {
    if (!rant) return null;

    return rant.text.split('\n').map((line, idx) => {
      if (line.trim().length === 0) return <div key={idx} className="h-4" />;
      
      if (line.startsWith('CHAPTER')) {
        return <h4 key={idx} className="text-roblox-red font-black text-xl mt-8 mb-4 uppercase tracking-tighter italic border-l-4 border-roblox-red pl-4">{line}</h4>;
      }
      if (line.startsWith('[VISUAL') || line.startsWith('[NARRATOR')) {
        return <div key={idx} className="text-[10px] font-black text-gray-500 bg-gray-900/50 p-1.5 px-3 rounded-lg mb-4 inline-block border border-gray-800 uppercase tracking-widest">{line}</div>;
      }
      return <p key={idx} className={`mb-6 transition-all duration-700 ${viewMode === 'teleprompter' ? 'text-5xl leading-tight font-black' : 'text-lg leading-relaxed text-gray-200'}`}>{line}</p>;
    });
  };

  if (!rant) {
    return (
      <div className="flex flex-col items-center justify-center h-full min-h-[500px] p-8 text-center bg-roblox-dark rounded-3xl border-2 border-dashed border-roblox group">
        <div className="w-24 h-24 bg-roblox-red/10 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
          <Icons.Flame />
        </div>
        <h3 className="text-2xl font-bebas tracking-widest text-white mb-2 uppercase italic">Studio Standby</h3>
        <p className="text-gray-500 text-sm max-w-xs mx-auto italic font-medium">Ready for recording. Generate a script to begin production.</p>
      </div>
    );
  }

  return (
    <div className="bg-roblox-dark rounded-3xl border border-roblox overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.5)] animate-fade-in flex flex-col h-full max-h-[850px] relative">
      {/* Studio Indicators */}
      <div className="absolute top-20 right-8 z-40 flex flex-col items-end space-y-2 pointer-events-none">
        {isPlaying && (
          <div className="flex items-center space-x-2 bg-red-600/10 px-3 py-1 rounded-full border border-red-600/20 backdrop-blur-md">
            <div className="w-2.5 h-2.5 bg-red-600 rounded-full animate-pulse shadow-[0_0_15px_rgba(220,38,38,0.8)]"></div>
            <span className="text-[10px] font-black text-red-600 uppercase tracking-widest">Live Narration</span>
          </div>
        )}
        {isPublishing && (
          <div className="flex items-center space-x-2 bg-blue-600/10 px-3 py-1 rounded-full border border-blue-600/20 backdrop-blur-md animate-bounce">
            <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Broadcasting...</span>
          </div>
        )}
      </div>

      {/* Header Bar */}
      <div className="bg-[#252a33] px-8 py-5 flex flex-wrap justify-between items-center border-b border-roblox gap-4">
        <div className="flex items-center space-x-5">
          <div className="flex space-x-2">
            <div className="w-3 h-3 bg-red-500 rounded-full shadow-lg shadow-red-500/20"></div>
            <div className="w-3 h-3 bg-yellow-500 rounded-full shadow-lg shadow-yellow-500/20"></div>
            <div className="w-3 h-3 bg-green-500 rounded-full shadow-lg shadow-green-500/20"></div>
          </div>
          <div className="h-6 w-[1px] bg-gray-700"></div>
          <span className="text-[11px] font-black text-gray-400 uppercase tracking-widest flex items-center">
            <span className="mr-2 opacity-50"><Icons.Edit /></span>
            {rant.config.topic.substring(0, 20)}_FINAL_CUT.MP4
          </span>
        </div>
        
        <div className="flex items-center bg-[#0b0d11] p-1.5 rounded-xl border border-roblox shadow-inner">
           <button 
             onClick={() => setViewMode('script')}
             className={`px-4 py-2 text-[10px] font-black uppercase rounded-lg transition-all ${viewMode === 'script' ? 'bg-roblox-red text-white shadow-lg' : 'text-gray-500 hover:text-white'}`}
           >
             Editor View
           </button>
           <button 
             onClick={() => setViewMode('teleprompter')}
             className={`px-4 py-2 text-[10px] font-black uppercase rounded-lg transition-all ${viewMode === 'teleprompter' ? 'bg-roblox-red text-white shadow-lg' : 'text-gray-500 hover:text-white'}`}
           >
             Teleprompter
           </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div 
        ref={scrollContainerRef}
        className={`flex-1 overflow-y-auto p-12 custom-scrollbar relative scroll-smooth ${viewMode === 'teleprompter' ? 'bg-black text-white text-center' : 'bg-transparent text-gray-200'}`}
      >
        {/* CRT Scanline FX */}
        <div className="absolute inset-0 pointer-events-none z-30 opacity-[0.04]" 
             style={{ background: 'linear-gradient(rgba(18,16,16,0) 50%, rgba(0,0,0,0.25) 50%), linear-gradient(90deg, rgba(255,0,0,0.06), rgba(0,255,0,0.02), rgba(0,0,255,0.06))', backgroundSize: '100% 4px, 3px 100%' }}></div>

        <div className="relative z-10 max-w-2xl mx-auto py-20">
          {renderContent()}
        </div>
        
        {isPlaying && duration > 0 && (
          <div className="fixed bottom-[88px] left-0 right-0 h-1 bg-roblox-red/10 z-50">
            <div 
              className="h-full bg-roblox-red animate-progress origin-left" 
              style={{ animationDuration: `${duration}s` }}
            ></div>
          </div>
        )}
      </div>

      {/* Footer Controls */}
      <div className="bg-[#0b0d11] px-8 py-5 border-t border-roblox flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button 
            onClick={handleSynthesize}
            disabled={isSynthesizing}
            className={`flex items-center space-x-3 px-6 py-3 rounded-2xl text-[11px] font-black uppercase tracking-widest transition-all ${
              isSynthesizing ? 'bg-gray-800 text-gray-500' : 
              isPlaying ? 'bg-red-900/40 text-red-500 border border-red-500/30' : 
              'bg-[#252a33] text-white hover:bg-[#2d333d] shadow-lg'
            }`}
          >
            {isSynthesizing ? (
              <div className="w-4 h-4 border-2 border-gray-500 border-t-transparent rounded-full animate-spin"></div>
            ) : isPlaying ? (
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
            ) : (
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
            )}
            <span>{isSynthesizing ? 'Syncing...' : isPlaying ? 'Stop Feed' : 'Launch Narration'}</span>
          </button>
          
          <button 
            onClick={handleDownload}
            className="p-3 text-gray-500 hover:text-white bg-[#252a33]/50 rounded-xl transition-all"
            title="Download Script"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
          </button>
        </div>

        <div className="flex items-center space-x-3">
          <button 
            onClick={handlePublish}
            disabled={isPublishing || isPublished}
            className={`flex items-center space-x-2 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] transition-all border ${
              isPublished ? 'bg-green-900/20 border-green-500 text-green-500' : 
              isPublishing ? 'bg-blue-900/20 border-blue-500 text-blue-500' : 
              'bg-[#252a33] border-gray-700 text-gray-400 hover:text-white hover:border-gray-500'
            }`}
          >
            {isPublished ? <Icons.Check /> : isPublishing ? <div className="w-3 h-3 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div> : <Icons.Share />}
            <span>{isPublished ? 'Published' : isPublishing ? 'Broadcasting' : 'Publish to Feed'}</span>
          </button>

          <button 
            onClick={handleCopy}
            className={`flex items-center space-x-3 px-8 py-3 rounded-2xl text-xs font-black transition-all uppercase tracking-widest ${copied ? 'bg-green-600 text-white' : 'bg-roblox-red text-white hover:bg-red-600 shadow-[0_10px_30px_rgba(246,65,65,0.3)] rage-pulse'}`}
          >
            {copied ? <Icons.Check /> : <Icons.Copy />}
            <span>{copied ? 'Copied' : 'Export'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default RantOutput;
