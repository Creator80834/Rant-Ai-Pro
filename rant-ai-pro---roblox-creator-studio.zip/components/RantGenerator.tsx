
import React, { useState, useMemo, useEffect } from 'react';
import { Intensity, Persona, RantConfig, RantLength, SlangStyle, SavedPreset, PlanType } from '../types';
import { POPULAR_TOPICS, GRIEVANCES, Icons, FEATURED_TOPICS } from '../constants';
import { generateTopicImage } from '../services/geminiService';

interface RantGeneratorProps {
  onGenerate: (config: RantConfig) => void;
  isGenerating: boolean;
  userPlan?: PlanType;
  onShowPricing: () => void;
}

const PRESETS_STORAGE_KEY = 'roblorant_presets_v2';

const PlanBadge: React.FC<{ type: 'PRO' | 'PREM' }> = ({ type }) => (
  <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-tighter ml-2 ${
    type === 'PRO' ? 'bg-roblox-red text-white' : 'bg-blue-600 text-white'
  }`}>
    <Icons.Lock />
    <span className="ml-0.5">{type}</span>
  </span>
);

const TooltipLabel: React.FC<{ label: string; text: string; htmlFor?: string }> = ({ label, text, htmlFor }) => {
  const tooltipId = `tooltip-${label.toLowerCase().replace(/\s+/g, '-')}`;
  return (
    <div className="flex items-center space-x-1.5 mb-2 group relative">
      <label 
        htmlFor={htmlFor}
        id={`${tooltipId}-label`}
        className="block text-xs font-bold text-gray-400 uppercase tracking-widest cursor-pointer"
      >
        {label}
      </label>
      <div 
        className="text-gray-600 hover:text-roblox-red transition-colors cursor-help"
        aria-describedby={tooltipId}
        tabIndex={0}
      >
        <Icons.Info />
      </div>
      <div 
        id={tooltipId}
        role="tooltip"
        className="absolute bottom-full left-0 mb-2 w-48 p-2 bg-black border border-roblox rounded text-[10px] text-gray-300 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-20 shadow-xl"
      >
        {text}
        <div className="absolute top-full left-4 w-2 h-2 bg-black border-r border-b border-roblox transform rotate-45 -translate-y-1"></div>
      </div>
    </div>
  );
};

const RantGenerator: React.FC<RantGeneratorProps> = ({ onGenerate, isGenerating, userPlan = PlanType.FREE, onShowPricing }) => {
  const [topic, setTopic] = useState('');
  const [target, setTarget] = useState('Everyone');
  const [intensity, setIntensity] = useState<Intensity>(Intensity.ANGRY);
  const [persona, setPersona] = useState<Persona>(Persona.VETERAN);
  const [length, setLength] = useState<RantLength>(RantLength.MEDIUM);
  const [selectedSlangStyles, setSelectedSlangStyles] = useState<SlangStyle[]>([SlangStyle.MODERN]);
  const [selectedGrievances, setSelectedGrievances] = useState<string[]>([]);
  
  const [customImage, setCustomImage] = useState<string | null>(null);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [savedPresets, setSavedPresets] = useState<SavedPreset[]>([]);
  const [showPresets, setShowPresets] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(PRESETS_STORAGE_KEY);
    if (stored) {
      try { setSavedPresets(JSON.parse(stored)); } catch (e) {}
    }
  }, []);

  const hasAccess = (requiredPlan: PlanType) => {
    if (userPlan === PlanType.PREMIUM) return true;
    if (userPlan === PlanType.PRO && requiredPlan !== PlanType.PREMIUM) return true;
    return userPlan === requiredPlan;
  };

  const handleIntensityChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value as Intensity;
    if ((val === Intensity.NUCLEAR || val === Intensity.TOXIC) && !hasAccess(PlanType.PREMIUM)) {
      onShowPricing();
      return;
    }
    setIntensity(val);
  };

  const handleLengthChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value as RantLength;
    if (val === RantLength.LONG && !hasAccess(PlanType.PRO)) {
      onShowPricing();
      return;
    }
    setLength(val);
  };

  const handleSlangToggle = (s: SlangStyle) => {
    if (s === SlangStyle.CLASSIC && !hasAccess(PlanType.PRO)) {
      onShowPricing();
      return;
    }
    if ((s === SlangStyle.GEN_ALPHA || s === SlangStyle.TECHNICAL) && !hasAccess(PlanType.PREMIUM)) {
      onShowPricing();
      return;
    }
    setSelectedSlangStyles(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);
  };

  const handleMagicImage = async () => {
    if (!hasAccess(PlanType.PRO)) {
      onShowPricing();
      return;
    }
    if (!topic.trim() || isGeneratingImage) return;
    setIsGeneratingImage(true);
    try {
      const img = await generateTopicImage(topic);
      setCustomImage(img);
    } catch (e) {
      console.error("Image generation failed", e);
    } finally { setIsGeneratingImage(false); }
  };

  const handleSavePreset = () => {
    if (!topic.trim()) return;
    const newPreset: SavedPreset = {
      id: Math.random().toString(36).substr(2, 9),
      name: topic.substring(0, 20),
      timestamp: Date.now(),
      config: { topic, target, intensity, persona, length, slangStyles: selectedSlangStyles, grievances: selectedGrievances }
    };
    const updated = [newPreset, ...savedPresets].slice(0, 10);
    setSavedPresets(updated);
    localStorage.setItem(PRESETS_STORAGE_KEY, JSON.stringify(updated));
    setShowPresets(true);
  };

  const loadPreset = (p: SavedPreset) => {
    setTopic(p.config.topic);
    setTarget(p.config.target || 'Everyone');
    setIntensity(p.config.intensity);
    setPersona(p.config.persona);
    setLength(p.config.length);
    setSelectedSlangStyles(p.config.slangStyles);
    setSelectedGrievances(p.config.grievances || []);
    setShowPresets(false);
  };

  const deletePreset = (id: string) => {
    const updated = savedPresets.filter(p => p.id !== id);
    setSavedPresets(updated);
    localStorage.setItem(PRESETS_STORAGE_KEY, JSON.stringify(updated));
  };

  const liveTonePreview = useMemo(() => {
    const openings: Record<Persona, string> = {
      [Persona.VETERAN]: "Back in 2008, we didn't have this garbage...",
      [Persona.NOOB]: "pls can someone explain why...",
      [Persona.DEVELOPER]: "Another day, another broken API in...",
      [Persona.RICH_KID]: "Imagine not having enough Robux to fix...",
      [Persona.GAMER_GIRL]: "The vibes in this update for...",
      [Persona.TRADER]: "Total L trade for anyone liking..."
    };
    const slangBuzz: Record<SlangStyle, string> = {
      [SlangStyle.CLASSIC]: "oof", [SlangStyle.MODERN]: "skill issue", 
      [SlangStyle.GEN_ALPHA]: "skibidi", [SlangStyle.TECHNICAL]: "Lua error"
    };
    const currentTopic = topic.trim() || "Roblox";
    const selectedSlang = selectedSlangStyles[0] || SlangStyle.MODERN;
    let base = `${openings[persona]} ${currentTopic} is just a total ${slangBuzz[selectedSlang]}.`;
    if (intensity === Intensity.NUCLEAR) base = base.toUpperCase() + "!!!1!!";
    else if (intensity === Intensity.ANGRY) base = base + "!!!";
    else if (intensity === Intensity.TOXIC) base = base.split('').map((char, i) => i % 2 === 0 ? char.toLowerCase() : char.toUpperCase()).join('') + " #######";
    return base;
  }, [topic, persona, intensity, selectedSlangStyles]);

  const previewImage = useMemo(() => {
    const featured = FEATURED_TOPICS.find(t => t.name === topic);
    return featured ? featured.image : (customImage || "https://images.unsplash.com/photo-1614741118887-7a4ee193a5fa?q=80&w=300&auto=format&fit=crop");
  }, [topic, customImage]);

  return (
    <div className="space-y-6">
      <form 
        onSubmit={(e) => {
          e.preventDefault();
          onGenerate({ topic, target, intensity, persona, length, slangStyles: selectedSlangStyles, grievances: selectedGrievances, topicImage: previewImage });
        }} 
        className="space-y-6 bg-roblox-dark p-6 rounded-xl border border-roblox shadow-2xl relative"
      >
        <div className="flex items-center justify-between pb-4 border-b border-roblox">
          <h3 className="text-sm font-black text-gray-400 uppercase tracking-tighter italic">Generator Config</h3>
          <button type="button" onClick={() => setShowPresets(!showPresets)} className={`px-3 py-1 rounded text-[10px] font-bold uppercase transition-all flex items-center space-x-2 ${showPresets ? 'bg-roblox-red text-white' : 'bg-[#252a33] text-gray-400 hover:text-white'}`}>
             <span>{showPresets ? 'Hide Presets' : `Presets (${savedPresets.length})`}</span>
          </button>
        </div>

        {showPresets && savedPresets.length > 0 && (
          <div className="bg-black/40 rounded-lg p-3 space-y-2 max-h-40 overflow-y-auto custom-scrollbar border border-roblox/50 animate-fade-in">
            {savedPresets.map(p => (
              <div key={p.id} className="flex items-center justify-between bg-[#1a1d23] p-2 rounded border border-roblox group/item">
                <button type="button" onClick={() => loadPreset(p)} className="flex-1 text-left text-[10px] text-gray-300 font-bold hover:text-roblox-red truncate">
                  {p.name}
                </button>
                <button type="button" onClick={() => deletePreset(p.id)} className="text-gray-600 hover:text-red-500 transition-colors opacity-0 group-hover/item:opacity-100 p-1">
                  <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="space-y-4">
          <div>
            <TooltipLabel htmlFor="rant-topic" label="Target / Topic" text="What are we raging about today?" />
            <div className="flex gap-4">
              <div className="w-16 h-16 rounded-lg overflow-hidden border border-roblox flex-shrink-0 bg-black/40 shadow-inner relative group/preview">
                 <img src={previewImage} alt="" className="w-full h-full object-cover opacity-80" />
                 {!FEATURED_TOPICS.some(t => t.name === topic) && topic.trim() && !isGeneratingImage && (
                   <button type="button" onClick={handleMagicImage} className="absolute inset-0 flex items-center justify-center bg-black/60 opacity-0 group-hover/preview:opacity-100 transition-opacity">
                      <Icons.Sparkles />
                      {!hasAccess(PlanType.PRO) && <PlanBadge type="PRO" />}
                   </button>
                 )}
                 {isGeneratingImage && (
                   <div className="absolute inset-0 flex items-center justify-center bg-black/60">
                      <div className="w-4 h-4 border-2 border-roblox-red border-t-transparent rounded-full animate-spin"></div>
                   </div>
                 )}
              </div>
              <input id="rant-topic" type="text" value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="e.g. New UI update..." className="flex-1 bg-[#0b0d11] border border-roblox rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-roblox-red" required />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <TooltipLabel label="Intensity" text="How mad are you?" />
              <select value={intensity} onChange={handleIntensityChange} className="w-full bg-[#0b0d11] border border-roblox rounded-lg px-3 py-2 text-xs text-white cursor-pointer hover:border-gray-500 focus:outline-none">
                <option value={Intensity.MILD}>{Intensity.MILD}</option>
                <option value={Intensity.ANGRY}>{Intensity.ANGRY}</option>
                <option value={Intensity.NUCLEAR}>NUCLEAR ⚡ [PREM]</option>
                <option value={Intensity.TOXIC}>TOXIC ☣️ [PREM]</option>
              </select>
            </div>
            <div className="space-y-2">
              <TooltipLabel label="Length" text="How long is the rage?" />
              <select value={length} onChange={handleLengthChange} className="w-full bg-[#0b0d11] border border-roblox rounded-lg px-3 py-2 text-xs text-white cursor-pointer hover:border-gray-500 focus:outline-none">
                <option value={RantLength.SHORT}>{RantLength.SHORT}</option>
                <option value={RantLength.MEDIUM}>{RantLength.MEDIUM}</option>
                <option value={RantLength.LONG}>ESSAY 📄 [PRO]</option>
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <TooltipLabel label="Persona" text="Who is doing the ranting?" />
            <select value={persona} onChange={(e) => setPersona(e.target.value as Persona)} className="w-full bg-[#0b0d11] border border-roblox rounded-lg px-3 py-2 text-xs text-white cursor-pointer hover:border-gray-500 focus:outline-none">
              {Object.values(Persona).map(p => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>

          <div className="space-y-2">
            <TooltipLabel label="Slang Engines" text="Enable specialized slang styles." />
            <div className="flex flex-wrap gap-2">
              {[SlangStyle.MODERN, SlangStyle.CLASSIC, SlangStyle.GEN_ALPHA, SlangStyle.TECHNICAL].map((s) => {
                const isLocked = (s === SlangStyle.CLASSIC && !hasAccess(PlanType.PRO)) || 
                                 ((s === SlangStyle.GEN_ALPHA || s === SlangStyle.TECHNICAL) && !hasAccess(PlanType.PREMIUM));
                return (
                  <button 
                    key={s} 
                    type="button" 
                    onClick={() => handleSlangToggle(s)} 
                    className={`text-[9px] px-2 py-1 rounded border transition-all flex items-center ${
                      selectedSlangStyles.includes(s) 
                        ? 'bg-roblox-red border-roblox-red text-white' 
                        : 'bg-[#0b0d11] border-roblox text-gray-500'
                    }`}
                  >
                    {s.split(' ')[0]}
                    {isLocked && <PlanBadge type={s === SlangStyle.CLASSIC ? 'PRO' : 'PREM'} />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-roblox">
          <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest flex items-center mb-2">
            <span className="w-1.5 h-1.5 bg-green-500 rounded-full mr-2 animate-pulse"></span>
            TONE_ANALYSIS.DLL
          </label>
          <div className="bg-black/40 border border-roblox/50 rounded-lg p-3 min-h-[50px] italic text-[11px] font-mono text-gray-400">
            <span className="text-roblox-red mr-1">{'>'}</span>{liveTonePreview}
          </div>
        </div>

        <div className="flex gap-3">
          <button 
            type="submit" 
            disabled={isGenerating} 
            className={`flex-1 py-4 rounded-xl font-bold text-lg flex items-center justify-center space-x-2 transition-all ${
              isGenerating ? 'bg-gray-600 opacity-50' : 'bg-roblox-red hover:bg-red-600 shadow-lg rage-pulse active:scale-95'
            }`}
          >
            {isGenerating ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div> : <><Icons.Flame /><span className="font-bebas tracking-widest text-2xl">EXECUTE RANT</span></>}
          </button>
          <button 
            type="button"
            onClick={handleSavePreset}
            disabled={!topic.trim()}
            className="w-14 bg-[#252a33] border border-roblox rounded-xl flex items-center justify-center text-gray-400 hover:text-white hover:bg-[#2d333d] transition-all disabled:opacity-30 active:scale-90"
            title="Save Config as Preset"
          >
            <Icons.Check />
          </button>
        </div>
      </form>
      
      <div className="grid grid-cols-2 gap-4">
        {FEATURED_TOPICS.slice(0, 4).map(t => (
          <button key={t.name} type="button" onClick={() => setTopic(t.name)} className="bg-roblox-dark border border-roblox p-2 rounded-lg flex items-center space-x-3 hover:border-roblox-red transition-all group text-left">
            <img src={t.image} className="w-8 h-8 rounded object-cover grayscale group-hover:grayscale-0 transition-all" alt="" />
            <span className="text-[10px] font-bold text-gray-500 group-hover:text-white truncate">{t.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default RantGenerator;
