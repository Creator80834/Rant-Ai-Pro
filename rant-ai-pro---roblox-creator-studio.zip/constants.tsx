
import React from 'react';
import { PlanType } from './types';

export const PRICING_PLANS = [
  {
    type: PlanType.FREE,
    name: 'Bacon Plan',
    price: 'Free',
    features: ['3 Generations / Day', 'Basic Personas', 'Modern Slang', 'Standard Intensity', '5 History Slots'],
    color: 'gray'
  },
  {
    type: PlanType.PRO,
    name: 'Veteran Pro',
    price: 'R$ 99',
    period: '/mo',
    features: ['Unlimited Generations', 'All Personas', 'Classic Slang', 'Long Essay Length', '50 History Slots', 'Magic AI Images'],
    color: 'red',
    popular: true
  },
  {
    type: PlanType.PREMIUM,
    name: 'Limiteds Elite',
    price: 'R$ 249',
    period: '/mo',
    features: ['Nuclear Intensity', 'Gen Alpha & Technical Slang', 'Priority Generation', 'Unlimited History', 'Ad-Free Experience', 'Premium Badge'],
    color: 'blue'
  }
];

export const FEATURED_TOPICS = [
  { 
    name: "Adopt Me!", 
    image: "https://images.unsplash.com/photo-1589182373726-e4f658ab50f0?q=80&w=300&auto=format&fit=crop",
    category: "RP"
  },
  { 
    name: "Blox Fruits", 
    image: "https://images.unsplash.com/photo-1552820728-8b83bb6b773f?q=80&w=300&auto=format&fit=crop",
    category: "Action"
  },
  { 
    name: "Brookhaven RP", 
    image: "https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?q=80&w=300&auto=format&fit=crop",
    category: "Social"
  },
  { 
    name: "Pet Simulator 99", 
    image: "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?q=80&w=300&auto=format&fit=crop",
    category: "Simulator"
  },
  { 
    name: "Doors", 
    image: "https://images.unsplash.com/photo-1519074063912-ad2a602159d7?q=80&w=300&auto=format&fit=crop",
    category: "Horror"
  },
  { 
    name: "Dress To Impress", 
    image: "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=300&auto=format&fit=crop",
    category: "Fashion"
  }
];

export const POPULAR_TOPICS = [
  "Roblox Moderation",
  "Adopt Me Scammers",
  "Bloxburg Paywall",
  "Slenders & Ro-gangsters",
  "The Catalog/UGC Prices",
  "Server Lag",
  "Pet Simulator 99 F2P",
  "Brookhaven RP Logic",
  "Tower of Hell",
  "Free Robux Scams",
  "Sol's RNG Aura Luck",
  "Headless Horseman Price",
  "Doors Floor 2 Difficulty",
  "Blox Fruits Update 21 Delay",
  "The 'Classic' Event",
  "Fake Limited Items",
  "VC Mic-up Drama",
  "Da Hood Toxicity",
  "Dress To Impress Rigging",
  "Berry Avenue RP Drama"
];

export const GRIEVANCES = [
  "Pay-to-win mechanics",
  "Toxic community",
  "Game-breaking bugs",
  "Endless microtransactions",
  "Abusive admins",
  "Fake advertisements",
  "Exploiters/Hackers",
  "Chat filters (#######)",
  "Copy-pasted games",
  "Bad physics",
  "AI Moderation fails",
  "Removed 'Oof' sound",
  "The 'Experience' rebrand",
  "UGC IP Infringement",
  "Mobile overheating",
  "Clickbait thumbnails",
  "No more Tix (Nostalgia)",
  "Unfair Ban Appeals",
  "Data loss in Tycoons",
  "Premium value decline"
];

export const Icons = {
  Flame: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.5-7 3 3 3.5 1.354 3.5 3.5-.01 3.335-1 5.827-1 5.827s.465 2.138 3.157 3.422c1.29.613 2.157 1.676 2.157 3.422a8 8 0 01-4.343 7.343z" />
    </svg>
  ),
  Refresh: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
    </svg>
  ),
  Copy: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m-3 4h.01M9 16h5m0 0a2 2 0 012 2v1a2 2 0 01-2 2H9a2 2 0 01-2-2v-1a2 2 0 012-2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
    </svg>
  ),
  Edit: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-5M18.364 5.636a9 9 0 010 12.728m0 0l-2.829-2.829m2.829 2.829L21 21M15.536 8.464a5 5 0 010 7.072m0 0l-2.122-2.122m2.122 2.122L17 17m-5.121-6.929V5l3.536 3.536L11.879 12.07z" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
    </svg>
  ),
  Check: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
    </svg>
  ),
  Info: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  ),
  Sun: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707m12.728 0l-.707-.707M6.343 6.343l-.707-.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
    </svg>
  ),
  Moon: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
    </svg>
  ),
  User: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
    </svg>
  ),
  Logout: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
    </svg>
  ),
  Sparkles: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
    </svg>
  ),
  ThumbUp: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10h4.708C19.743 10 20.5 10.832 20.5 11.856c0 .414-.141.803-.383 1.111l-3.327 4.225c-.21.267-.532.423-.873.423H9V10l3-5c.5-1 1.5-1.5 2.5-1s1.5 1.5 1.5 2.5v3.5" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 10H5a2 2 0 00-2 2v6a2 2 0 002 2h4V10z" />
    </svg>
  ),
  ThumbDown: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14H5.292C4.257 14 3.5 13.168 3.5 12.144c0-.414.141-.803.383-1.111l3.327-4.225c.21-.267.532-.423.873-.423H15V14l-3 5c-.5 1-1.5 1.5-2.5 1s-1.5-1.5-1.5-2.5V14" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 14h4a2 2 0 002-2V6a2 2 0 00-2-2h-4v10z" />
    </svg>
  ),
  Share: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
    </svg>
  ),
  Lock: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
    </svg>
  )
};
