
import React, { useState, useEffect, useRef } from 'react';
import RantGenerator from './components/RantGenerator';
import RantOutput from './components/RantOutput';
import RantHistory from './components/RantHistory';
import AuthModal from './components/AuthModal';
import PricingSection from './components/PricingSection';
import { RantConfig, GeneratedRant, User, PlanType } from './types';
import { generateRobloxRant } from './services/geminiService';
import { Icons, POPULAR_TOPICS } from './constants';

const STORAGE_KEY = 'roblorant_history_v1';
const USER_KEY = 'roblorant_user_v1';

const INITIAL_FEED = [
  {user: "VetroGamer", topic: "Blox Fruits Delay", time: "2m ago", views: "14.2k", isNew: false},
  {user: "BaconMaster", topic: "Adopt Me Scams", time: "15m ago", views: "8.1k", isNew: false},
  {user: "UGC_Dev_Rob", topic: "UGC Fee Hike", time: "1h ago", views: "25.9k", isNew: false}
];

const App: React.FC = () => {
  const [currentRant, setCurrentRant] = useState<GeneratedRant | null>(null);
  const [history, setHistory] = useState<GeneratedRant[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [onlineCreators, setOnlineCreators] = useState(1240);
  const [communityFeed, setCommunityFeed] = useState(INITIAL_FEED);
  const [notifications, setNotifications] = useState<{id: number, text: string}[]>([]);
  
  const pricingRef = useRef<HTMLDivElement>(null);
  const outputRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const savedHistory = localStorage.getItem(STORAGE_KEY);
    if (savedHistory) try { setHistory(JSON.parse(savedHistory)); } catch (e) {}
    const savedUser = localStorage.getItem(USER_KEY);
    if (savedUser) try { setCurrentUser(JSON.parse(savedUser)); } catch (e) {}

    const interval = setInterval(() => {
      setOnlineCreators(prev => prev + (Math.random() > 0.5 ? 1 : -1));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => localStorage.setItem(STORAGE_KEY, JSON.stringify(history)), [history]);

  const addNotification = (text: string) => {
    const id = Date.now();
    setNotifications(prev => [...prev, {id, text}]);
    setTimeout(() => setNotifications(prev => prev.filter(n => n.id !== id)), 4000);
  };

  const handleGenerate = async (config: RantConfig) => {
    setIsGenerating(true);
    if (window.innerWidth < 1024) outputRef.current?.scrollIntoView({ behavior: 'smooth' });
    
    try {
      const text = await generateRobloxRant(config);
      const newRant: GeneratedRant = { text, timestamp: Date.now(), config };
      setCurrentRant(newRant);
      setHistory(prev => [newRant, ...prev].slice(0, 20));
      addNotification("Script Ready for Production.");
    } catch (err) {
      addNotification("Critical Engine Failure.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePublished = () => {
    if (!currentRant) return;
    setCommunityFeed(prev => [{
      user: currentUser?.username || "Guest_Bacon",
      topic: currentRant.config.topic,
      time: "Just now",
      views: "1.2k",
      isNew: true
    }, ...prev].slice(0, 8));
    addNotification("Broadcast Sent to Feed.");
  };

  return (
    <div className="min-h-screen flex flex-col selection:bg-roblox-red selection:text-white">
      {/* Toast System */}
      <div className="fixed top-24 right-8 z-[120] flex flex-col space-y-3">
        {notifications.map(n => (
          <div key={n.id} className="bg-roblox-red text-white px-6 py-3 rounded-2xl shadow-2xl font-black text-[10px] uppercase tracking-widest animate-fade-in flex items-center space-x-3 border border-white/10">
            <Icons.Check />
            <span>{n.text}</span>
          </div>
        ))}
      </div>

      <header className="py-5 px-8 border-b border-roblox sticky top-0 z-50 bg-[#0b0d11]/90 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4 cursor-pointer" onClick={() => window.scrollTo({top:0, behavior:'smooth'})}>
            <div className="w-12 h-12 bg-roblox-red rounded-xl flex items-center justify-center shadow-2xl transform hover:rotate-6 transition-transform">
              <span className="text-3xl font-black text-white italic">R</span>
            </div>
            <h1 className="text-2xl font-bebas tracking-wider text-white">RANT<span className="text-roblox-red"> STUDIO</span></h1>
          </div>
          
          <div className="flex items-center space-x-8">
            <div className="hidden lg:flex flex-col items-end mr-6 pr-6 border-r border-roblox">
              <span className="text-[10px] font-black text-white uppercase">{onlineCreators.toLocaleString()} CREATORS</span>
              <span className="text-[8px] font-bold text-gray-500 uppercase tracking-widest">ACTIVE IN STUDIO</span>
            </div>
            <button onClick={() => setIsHistoryOpen(true)} className="text-[10px] font-black text-gray-400 hover:text-white uppercase tracking-widest">LOGS</button>
            {currentUser ? (
              <button onClick={() => setCurrentUser(null)} className="flex items-center space-x-3 bg-white/5 px-4 py-2 rounded-xl border border-roblox hover:border-gray-500 transition-all">
                <img src={`https://picsum.photos/seed/${currentUser.avatarSeed}/32/32`} className="w-8 h-8 rounded-lg" alt="" />
                <span className="text-xs font-black text-white uppercase">{currentUser.username}</span>
              </button>
            ) : (
              <button onClick={() => setIsAuthOpen(true)} className="bg-white text-black px-6 py-2.5 rounded-xl text-xs font-black tracking-widest uppercase hover:bg-roblox-red hover:text-white transition-all">LOG IN</button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto pt-24 pb-12 px-8 w-full">
        <div className="text-center mb-24 animate-fade-in">
          <h2 className="text-9xl md:text-[13rem] font-bebas tracking-tighter text-white mb-4 leading-none select-none italic">VIRAL <span className="text-roblox-red">DRAMA.</span></h2>
          <p className="text-gray-400 text-xl max-w-2xl mx-auto font-medium">Generate high-retention video scripts for the Roblox creator economy.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start mb-24">
          <div className="lg:col-span-5 lg:sticky lg:top-32">
            <RantGenerator 
              onGenerate={handleGenerate} 
              isGenerating={isGenerating} 
              userPlan={currentUser?.plan}
              onShowPricing={() => pricingRef.current?.scrollIntoView({behavior:'smooth'})}
            />
          </div>
          <div ref={outputRef} className="lg:col-span-7">
            <RantOutput 
              rant={currentRant} 
              onPublished={handlePublished}
            />
          </div>
        </div>

        {/* Community Dashboard */}
        <div className="mb-24">
          <h3 className="text-3xl font-bebas tracking-wider text-white uppercase mb-8">GLOBAL <span className="text-roblox-red">FEED</span></h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {communityFeed.map((item, idx) => (
              <div key={idx} className={`bg-roblox-dark border border-roblox p-6 rounded-2xl hover:border-roblox-red transition-all cursor-pointer relative overflow-hidden ${item.isNew ? 'ring-1 ring-roblox-red' : ''}`}>
                <div className="flex justify-between items-center mb-4">
                  <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{item.time}</span>
                  <span className="text-[10px] font-black text-roblox-red uppercase flex items-center">
                    <span className="w-1.5 h-1.5 bg-roblox-red rounded-full mr-2 animate-pulse"></span>
                    {item.views}
                  </span>
                </div>
                <h4 className="text-white font-black text-lg mb-2 uppercase line-clamp-2">{item.topic}</h4>
                <p className="text-gray-500 text-[10px] font-bold uppercase tracking-widest">@{item.user}</p>
              </div>
            ))}
          </div>
        </div>

        <div ref={pricingRef}>
          <PricingSection currentPlan={currentUser?.plan} onUpgrade={(p) => {
            if(currentUser) setCurrentUser({...currentUser, plan: p});
            else setIsAuthOpen(true);
          }} />
        </div>
      </main>

      <footer className="py-20 border-t border-roblox bg-black">
        <div className="max-w-7xl mx-auto px-8 flex flex-col md:flex-row justify-between items-center gap-12">
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 bg-roblox-red rounded-xl flex items-center justify-center"><span className="text-2xl font-black text-white italic">R</span></div>
            <div>
              <p className="text-white text-sm font-black uppercase tracking-widest">RANT AI PRO STUDIO</p>
              <p className="text-gray-600 text-[10px] font-bold uppercase tracking-[0.3em]">Build 4.0.2 • Verified Official</p>
            </div>
          </div>
          <p className="text-gray-700 text-[9px] font-bold uppercase tracking-[0.5em]">NOT AFFILIATED WITH ROBLOX CORP.</p>
        </div>
      </footer>

      <RantHistory history={history} isOpen={isHistoryOpen} onClose={() => setIsHistoryOpen(false)} onSelect={setCurrentRant} onClear={() => setHistory([])} onDelete={(ts) => setHistory(prev => prev.filter(r => r.timestamp !== ts))} />
      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} onSuccess={setCurrentUser} />
    </div>
  );
};

export default App;
