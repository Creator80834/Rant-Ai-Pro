
export enum PlanType {
  FREE = 'FREE',
  PRO = 'PRO',
  PREMIUM = 'PREMIUM'
}

export enum Intensity {
  MILD = 'Mildly Annoyed',
  ANGRY = 'Furious',
  NUCLEAR = 'Nuclear Meltdown',
  TOXIC = 'Average 9-Year-Old'
}

export enum Persona {
  VETERAN = 'Roblox Veteran (2008)',
  NOOB = 'Bacon Hair Noob',
  DEVELOPER = 'Stressed Dev',
  RICH_KID = 'Rich Kid with too much Robux',
  GAMER_GIRL = 'Aesthetic Gamer Girl',
  TRADER = 'Limiteds Trader'
}

export enum RantLength {
  SHORT = 'Short & Punchy',
  MEDIUM = 'Standard Rant',
  LONG = 'Full Essay'
}

export enum SlangStyle {
  CLASSIC = 'Old School (Oof, Tycoon, Guest)',
  MODERN = 'Modern (Slender, Ro-bio, Mic Up)',
  GEN_ALPHA = 'Brainrot (Skibidi, Ohio, Rizz - Roblox edition)',
  TECHNICAL = 'Dev Slang (Lua, API, DataStores)'
}

export interface RantConfig {
  topic: string;
  intensity: Intensity;
  persona: Persona;
  length: RantLength;
  slangStyles: SlangStyle[];
  grievances: string[];
  target: string;
  topicImage?: string;
}

export interface SavedPreset {
  id: string;
  name: string;
  config: RantConfig;
  timestamp: number;
}

export interface GeneratedRant {
  text: string;
  timestamp: number;
  config: RantConfig;
  feedback?: 'up' | 'down';
}

export interface User {
  username: string;
  email: string;
  avatarSeed: string;
  plan: PlanType;
  joinDate: number;
}
