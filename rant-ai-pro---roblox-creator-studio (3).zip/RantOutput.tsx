
import React, { useState } from 'react';
import { GeneratedRant } from './types.ts';
import { Icons } from './constants.tsx';
import { generateAudioRant } from './geminiService.ts';

interface RantOutputProps {
  rant: GeneratedRant | null;
  onPublished?: () => void;
}

const RantOutput: React.FC<RantOutputProps> = ({ rant, onPublished }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isSynthesizing, setIsSynthesizing] = useState(false);

  const handlePlay = async () => {
    if (!rant || isSynthesizing) return;
    setIsSynthesizing(true);
    try {
      const buffer = await generateAudioRant(rant.text, rant.config.persona);
      const AudioContextClass = (window as any).AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioContextClass();
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.connect(ctx.destination);
      source.onended = () => setIsPlaying(false);
      source.start(0);
      setIsPlaying(true);
    } catch (e) {
      alert("Audio Synth Failed. Please try again.");
    } finally {
      setIsSynthesizing(false);
    }
  };

  if (!rant) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[500px] border-2 border-dashed border-white/5 rounded-3xl p-12 text-center bg-black/20">
        <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center mb-6 text-gray-700">
          <Icons.Flame />
        </div>
        <h3 className="text-xl font-bebas text-white uppercase tracking-widest opacity-50">Studio Standby</h3>
        <p className="text-gray-600 text-[10px] font-black uppercase tracking-[0.3em] mt-2">Ready for execution</p>
      </div>
    );
  }

  return (
    <div className="bg-[#16181d] rounded-3xl border border-white/5 overflow-hidden shadow-2xl flex flex-col h-full max-h-[700px]">
      <div className="bg-black/40 p-5 flex justify-between items-center border-b border-white/5">
        <span className="text-[10px] font-black text-roblox-red uppercase tracking-widest">LIVE SCRIPT: {rant.config.topic}</span>
        <div className="flex space-x-1.5">
           <div className="w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(239,68,68,0.5)]"></div>
           <div className="w-2.5 h-2.5 bg-gray-700 rounded-full"></div>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-10 bg-black text-gray-300 font-mono text-xs space-y-6 custom-scrollbar leading-relaxed">
        {rant.text.split('\n').map((line, i) => (
          <p key={i} className={line.startsWith('CHAPTER') ? 'text-roblox-red font-black text-lg py-2' : line.startsWith('[VISUAL') ? 'text-gray-600 italic text-[10px]' : ''}>
            {line}
          </p>
        ))}
      </div>

      <div className="bg-black p-6 border-t border-white/5 flex gap-4">
        <button 
          onClick={handlePlay} 
          disabled={isSynthesizing}
          className="flex-1 py-3 bg-white/5 border border-white/10 rounded-xl text-[10px] font-black uppercase text-white hover:bg-white/10 transition-all disabled:opacity-30"
        >
          {isSynthesizing ? "SYNTHESIZING..." : isPlaying ? "PLAYING AUDIO..." : "SYNC NARRATION"}
        </button>
        <button 
          onClick={onPublished}
          className="flex-1 py-3 bg-roblox-red rounded-xl text-[10px] font-black uppercase text-white hover:bg-red-600 transition-all shadow-lg"
        >
          PUBLISH TO FEED
        </button>
      </div>
    </div>
  );
};

export default RantOutput;
