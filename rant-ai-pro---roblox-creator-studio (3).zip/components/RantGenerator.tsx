
import React, { useState } from 'react';
import { Intensity, Persona, RantConfig, RantLength, SlangStyle, PlanType } from '../types';
import { Icons } from '../constants';

interface RantGeneratorProps {
  onGenerate: (config: RantConfig) => void;
  isGenerating: boolean;
  userPlan?: PlanType;
  onShowPricing: () => void;
}

const RantGenerator: React.FC<RantGeneratorProps> = ({ onGenerate, isGenerating, userPlan = PlanType.FREE, onShowPricing }) => {
  const [topic, setTopic] = useState('');
  const [target, setTarget] = useState('Everyone');
  const [intensity, setIntensity] = useState<Intensity>(Intensity.ANGRY);
  const [persona, setPersona] = useState<Persona>(Persona.VETERAN);
  const [length, setLength] = useState<RantLength>(RantLength.MEDIUM);
  const [selectedSlangStyles, setSelectedSlangStyles] = useState<SlangStyle[]>([SlangStyle.MODERN]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate({ topic, target, intensity, persona, length, slangStyles: selectedSlangStyles, grievances: [] });
  };

  return (
    <div className="bg-roblox-dark p-6 rounded-xl border border-roblox shadow-2xl space-y-6">
      <h3 className="text-xs font-black text-gray-500 uppercase tracking-widest italic border-b border-roblox pb-4">Production Config</h3>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-[10px] font-black text-gray-500 uppercase mb-2">Topic</label>
          <input 
            type="text" 
            value={topic} 
            onChange={(e) => setTopic(e.target.value)} 
            placeholder="e.g. Server Lag..." 
            className="w-full bg-[#0b0d11] border border-roblox rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-roblox-red outline-none" 
            required 
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-[10px] font-black text-gray-500 uppercase mb-2">Intensity</label>
            <select value={intensity} onChange={(e) => setIntensity(e.target.value as Intensity)} className="w-full bg-[#0b0d11] border border-roblox rounded-lg px-3 py-2 text-xs text-white outline-none">
              {Object.values(Intensity).map(i => <option key={i} value={i}>{i}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-[10px] font-black text-gray-500 uppercase mb-2">Persona</label>
            <select value={persona} onChange={(e) => setPersona(e.target.value as Persona)} className="w-full bg-[#0b0d11] border border-roblox rounded-lg px-3 py-2 text-xs text-white outline-none">
              {Object.values(Persona).map(p => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>
        </div>

        <button 
          type="submit" 
          disabled={isGenerating} 
          className="w-full py-4 bg-roblox-red hover:bg-red-600 text-white rounded-xl font-black tracking-widest text-lg transition-all active:scale-95 disabled:opacity-50"
        >
          {isGenerating ? "GENERATING..." : "EXECUTE RANT"}
        </button>
      </form>
    </div>
  );
};

export default RantGenerator;
