
import React, { useState, useMemo } from 'react';
import { GeneratedRant } from '../types';
import { Icons } from '../constants';

interface RantHistoryProps {
  history: GeneratedRant[];
  isOpen: boolean;
  onClose: () => void;
  onSelect: (rant: GeneratedRant) => void;
  onClear: () => void;
  onDelete: (timestamp: number) => void;
}

const RantHistory: React.FC<RantHistoryProps> = ({ 
  history, 
  isOpen, 
  onClose, 
  onSelect, 
  onClear,
  onDelete
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredHistory = useMemo(() => {
    if (!searchQuery.trim()) return history;

    const query = searchQuery.trim();
    // Split by OR (case insensitive, whole word)
    const orSegments = query.split(/\s+OR\s+/);

    return history.filter(rant => {
      const content = `${rant.config.topic} ${rant.text}`.toLowerCase();
      
      // OR logic: at least one segment must match
      return orSegments.some(segment => {
        // Tokenize segment while preserving phrases in quotes
        // Matches: "phrase here" or -word or NOT or word
        const tokens = segment.match(/"[^"]+"|\S+/g) || [];
        if (tokens.length === 0) return false;

        let segmentMatches = true;
        let hasPositiveTerms = false;

        for (let i = 0; i < tokens.length; i++) {
          let token = tokens[i];
          let isNegative = false;

          // Handle NOT operator
          if (token.toUpperCase() === 'NOT' && i + 1 < tokens.length) {
            isNegative = true;
            token = tokens[++i];
          } else if (token.startsWith('-')) {
            isNegative = true;
            token = token.substring(1);
          }

          // Strip quotes from phrase tokens
          const cleanToken = token.replace(/^"|"$/g, '').toLowerCase();
          if (!cleanToken) continue;

          const found = content.includes(cleanToken);

          if (isNegative) {
            if (found) {
              segmentMatches = false;
              break;
            }
          } else {
            // Implicit AND within the segment
            hasPositiveTerms = true;
            if (!found) {
              segmentMatches = false;
              break;
            }
          }
        }

        // If no positive terms were provided (e.g., query is just "NOT bad"),
        // it matches as long as the negative condition is met.
        return segmentMatches;
      });
    });
  }, [history, searchQuery]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-6">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/80 backdrop-blur-sm" 
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="relative w-full max-w-2xl bg-roblox-dark border border-roblox rounded-2xl shadow-2xl flex flex-col max-h-[80vh] overflow-hidden animate-fade-in">
        <div className="p-6 border-b border-roblox flex flex-col gap-4 bg-[#252a33]">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-roblox-red/20 rounded-lg text-roblox-red">
                <Icons.Refresh />
              </div>
              <h2 className="text-xl font-bebas tracking-wider text-white">Rant History</h2>
            </div>
            <div className="flex items-center space-x-4">
              {history.length > 0 && (
                <button 
                  onClick={onClear}
                  className="text-[10px] font-bold text-gray-500 hover:text-roblox-red uppercase tracking-widest transition-colors"
                >
                  Clear All
                </button>
              )}
              <button 
                onClick={onClose}
                className="text-gray-400 hover:text-white transition-colors p-1"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>

          {/* Search Bar */}
          <div className="space-y-2">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <svg className="h-4 w-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              <input
                type="text"
                placeholder="Search logs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#0b0d11] border border-roblox rounded-lg pl-10 pr-10 py-2.5 text-sm text-white focus:outline-none focus:ring-1 focus:ring-roblox-red transition-all"
              />
              <div className="absolute inset-y-0 right-0 flex items-center pr-2 space-x-1">
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="text-gray-500 hover:text-white p-1"
                  >
                    <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                )}
                <div className="group relative">
                  <div className="text-gray-600 hover:text-white transition-colors cursor-help p-1">
                    <Icons.Info />
                  </div>
                  <div className="absolute top-full right-0 mt-2 w-64 p-3 bg-black border border-roblox rounded-lg text-[10px] text-gray-300 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-[110] shadow-2xl leading-relaxed">
                    <p className="font-bold text-roblox-red mb-1 uppercase">Advanced Search</p>
                    <ul className="space-y-1 list-disc pl-3">
                      <li><code className="text-white">"Phrase Search"</code> - Match exact phrases.</li>
                      <li><code className="text-white">OR</code> - Match either term (e.g. <span className="italic">lag OR ping</span>).</li>
                      <li><code className="text-white">NOT</code> or <code className="text-white">-</code> - Exclude terms (e.g. <span className="italic">-toxic</span>).</li>
                      <li>Spaces act as implicit <code className="text-white">AND</code>.</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 custom-scrollbar space-y-4">
          {history.length === 0 ? (
            <div className="text-center py-20">
              <div className="flex justify-center opacity-20 mb-4">
                <Icons.Flame />
              </div>
              <p className="text-gray-500 font-medium">No rants in your logs yet.</p>
              <p className="text-gray-600 text-sm">Generate some absolute cinema first!</p>
            </div>
          ) : filteredHistory.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-gray-500 font-medium">No matches found for your query.</p>
              <button 
                onClick={() => setSearchQuery('')}
                className="mt-2 text-roblox-red text-xs font-bold uppercase hover:underline"
              >
                Clear Search
              </button>
            </div>
          ) : (
            filteredHistory.map((rant) => (
              <div 
                key={rant.timestamp}
                className="group relative bg-[#0b0d11] border border-roblox rounded-xl p-4 hover:border-roblox-red transition-all cursor-pointer"
                onClick={() => {
                  onSelect(rant);
                  onClose();
                }}
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-white font-bold text-sm truncate pr-8">
                    {rant.config.topic}
                  </h3>
                  <span className="text-[10px] text-gray-600 font-mono whitespace-nowrap">
                    {new Date(rant.timestamp).toLocaleDateString()} {new Date(rant.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <p className="text-gray-400 text-xs line-clamp-2 mb-3 italic">
                  "{rant.text.substring(0, 120)}..."
                </p>
                <div className="flex gap-2">
                  <span className="text-[9px] bg-[#252a33] text-gray-400 px-2 py-0.5 rounded uppercase font-bold">
                    {rant.config.intensity}
                  </span>
                  <span className="text-[9px] bg-[#252a33] text-gray-400 px-2 py-0.5 rounded uppercase font-bold">
                    {rant.config.persona}
                  </span>
                </div>
                
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete(rant.timestamp);
                  }}
                  className="absolute top-4 right-4 text-gray-700 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all p-1"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
              </div>
            ))
          )}
        </div>
        
        <div className="p-4 bg-[#0b0d11] border-t border-roblox text-center">
          <p className="text-[10px] text-gray-600 uppercase font-bold tracking-[0.2em]">
            {filteredHistory.length} {filteredHistory.length === 1 ? 'Rant' : 'Rants'} matching
          </p>
        </div>
      </div>
    </div>
  );
};

export default RantHistory;
