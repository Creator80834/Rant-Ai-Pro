
import React from 'react';
import { PRICING_PLANS, Icons } from '../constants';
import { PlanType } from '../types';

interface PricingSectionProps {
  currentPlan?: PlanType;
  onUpgrade: (plan: PlanType) => void;
}

const PricingSection: React.FC<PricingSectionProps> = ({ currentPlan, onUpgrade }) => {
  return (
    <div className="py-20 bg-roblox-dark/30 border-t border-roblox">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bebas tracking-wider text-white mb-4">UPGRADE YOUR <span className="text-roblox-red">RAGE</span></h2>
          <p className="text-gray-500 max-w-2xl mx-auto">Get access to vintage slang, nuclear intensity, and the elite Gen Alpha engine to dominate every Roblox comment section.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {PRICING_PLANS.map((plan) => {
            const isCurrent = currentPlan === plan.type;
            const isFree = plan.type === PlanType.FREE;
            
            return (
              <div 
                key={plan.type} 
                className={`relative bg-roblox-dark border-2 rounded-2xl p-8 flex flex-col h-full transition-all duration-300 hover:scale-[1.02] ${
                  plan.popular ? 'border-roblox-red shadow-[0_0_40px_rgba(246,65,65,0.1)]' : 'border-roblox hover:border-gray-600'
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-roblox-red text-white px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-[0.2em] shadow-lg">
                    Most Popular
                  </div>
                )}

                <div className="mb-8">
                  <h3 className="text-xs font-black text-gray-500 uppercase tracking-widest mb-2 italic">{plan.name}</h3>
                  <div className="flex items-baseline space-x-1">
                    <span className="text-4xl font-bebas text-white tracking-tighter">{plan.price}</span>
                    {plan.period && <span className="text-gray-500 text-sm">{plan.period}</span>}
                  </div>
                </div>

                <ul className="space-y-4 mb-10 flex-grow">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center space-x-3 text-sm text-gray-400">
                      <div className="flex-shrink-0 w-4 h-4 rounded-full bg-green-500/10 flex items-center justify-center text-green-500">
                        <Icons.Check />
                      </div>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                <button 
                  onClick={() => !isCurrent && onUpgrade(plan.type)}
                  className={`w-full py-4 rounded-xl font-bold uppercase tracking-widest transition-all ${
                    isCurrent 
                      ? 'bg-gray-800 text-gray-500 cursor-default' 
                      : isFree 
                        ? 'bg-[#252a33] text-white hover:bg-[#2d333d]' 
                        : 'bg-roblox-red text-white hover:bg-red-600 shadow-lg'
                  }`}
                >
                  <span className="font-bebas text-xl">
                    {isCurrent ? 'Current Plan' : isFree ? 'Selected' : 'Buy Now'}
                  </span>
                </button>
              </div>
            );
          })}
        </div>

        <div className="mt-12 p-6 bg-blue-900/10 border border-blue-500/30 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center space-x-4 text-center md:text-left">
            <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg">
              <Icons.Sparkles />
            </div>
            <div>
              <h4 className="text-white font-bold">ROBLO-PLUS SECURITY ENABLED</h4>
              <p className="text-blue-400 text-xs uppercase font-bold tracking-widest mt-1">Transactions handled by safe-blox-pay.exe</p>
            </div>
          </div>
          <p className="text-gray-500 text-[10px] max-w-xs text-center md:text-right">
            By purchasing, you agree to the community guidelines. No refunds on digital Bobux-equivalent goods. 
          </p>
        </div>
      </div>
    </div>
  );
};

export default PricingSection;
